
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

This package contains sample OpenPGP wrapper services

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

History

1.0: 20040220: initial release
1.1: 20040310: fixed a typo in config file

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Installation:

- Install and configure your OpenPGP installation first

- Put the package into the replicate/inbound directory

- Activate the package via the Web administrator

- Edit the config/openpgp.properties file as needed

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Legal notice:

IMPORTANT NOTICE:  Utilities and samples shown here are not official
parts of the webMethods product line.  These utilities and samples are
provided strictly "as is," and are not eligible for technical support
through webMethods Technical Services.  webMethods makes no guarantees
or warranties pertaining to the functionality, scalability, robustness,
or degree of testing of these utilities and samples, and assumes
absolutely no liability for any damages relating to them.  Customers are
strongly advised to consider these utilities and samples as "working
examples" from which they should build and test their own solutions.
While no support is provided, webMethods will provide limited assistance
in using this sample software.  Please direct questions or comments on
this software to security@webMethods.com.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=